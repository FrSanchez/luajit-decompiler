return {
	draft4 = "kong.tools.json-schema.draft4",
	kong = "kong.plugins.request-validator.kong"
}
